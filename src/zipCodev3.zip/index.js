'use strict';
var Alexa = require("alexa-sdk");
const https = require("https");
var deviceId;
var consentToken;
var userZip;
var marketResult;


exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
       console.log("deviceId: ", this.event.context.System.device.deviceId);
       this.event.context.System.device.deviceId !== undefined ? deviceId = this.event.context.System.device.deviceId
                                                               : deviceId = undefined;
       console.log("permissions: " , this.event.context.System.user.permissions);
       
       this.event.context.System.user.permissions !== undefined ? consentToken = this.event.context.System.user.permissions.consentToken 
                                                               : consentToken = undefined;

       console.log("consentToken: ", consentToken);
       if(deviceId !== undefined && consentToken !== undefined){
        requestZip(deviceId, consentToken, (zip) => {
                console.log("sent deviceId  : " + deviceId)
                console.log("sent consentToken: " + consentToken)
                console.log("received :" + zip);
                userZip = zip;
                this.emit(":tell", `the local zip code is: ${userZip}`);
            }); 
       }
       else if(deviceId){
        var permissions = ['read::alexa:device:all:address:country_and_postal_code']
        this.emit(":tellWithPermissionCard", "Please use the Alexa skills app to enable your location", permissions);
       }
       else{
        this.emit(":tell", "Please use a proper device to access this skill. Goodbye!")
       }
    },
    'SearchNearMe': function () {
        deviceId = this.event.context.System.device.deviceId;
        if(deviceId){
            consentToken = this.event.context.System.user.permissions.consentToken;           
        }
        else{
            this.emit(":tell", 'Please authorize the proper permissions')
        }  
    }
};

function requestZip(deviceId, consentToken, callback) {

    var options = {
        hostname: 'api.amazonalexa.com',
        port: 443,
        path: `/v1/devices/${deviceId}/settings/address/countryAndPostalCode`,                
        method: 'GET',
        headers: {
            Authorization: `Bearer ${consentToken}`
        },
        accept: 'application/json'
    };

    var req = https.request(options, res => {
        res.setEncoding('utf8');
        var returnData;

        res.on('data', data => {
            console.log("data is: ", data)
            returnData = data;
        });

        res.on('end', () => {
            console.log("return data is: ", returnData)
            var zip = JSON.parse(returnData).postalCode;
            console.log("zip is: ", zip)
            callback(zip);  // this will execute whatever function the caller defined, with one argument

        });

    });
    req.end();
}

