'use strict';
var Alexa = require("alexa-sdk");
const https = require("https");
var deviceId;
var consentToken;
var userZip;
var user;

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
       deviceId = this.event.context.System.device.deviceId;
       user = this.event.context.System.user;
       if(deviceId !== undefined){
        consentToken = user.permissions.consentToken
        this.emit(":tell", `Welcome, your consentToken is : ${consentToken}`);
       }
       else{
        this.emit(":tell", "Welcome");
       }
       
    },
    'SearchNearMe': function () {
        this.emit('SayHello');
    },
    'SayHello': function () {
        this.emit(':tell', 'Hello World!');
    }
};