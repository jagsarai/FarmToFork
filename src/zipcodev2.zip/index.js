'use strict';
var Alexa = require("alexa-sdk");
const https = require("https");
var deviceId;
var consentToken;
var userZip;
var user;

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
       deviceId = this.event.context.System.device.deviceId;
       user = this.event.context.System.user;
       if(deviceId){
        consentToken = user.permissions.consentToken
        this.emit(":tell", `Welcome, your consentToken is : ${consentToken}`);
       }
       else{
        this.emit(":tell", "Welcome");
       }
    },
    'SearchNearMe': function () {
        deviceId = this.event.context.System.device.deviceId;
        if(deviceId){
            consentToken = this.event.context.System.user.permissions.consentToken;
            httpsGet(deviceId, consentToken, (result) => {
                console.log("sent deviceId  : " + deviceId)
                console.log("sent consentToken: " + consentToken)
                console.log("received :" + result);
                this.emit(":tell", `the local zip code is: ${result}`);
            });            
        }
        else{
            this.emit(":tell", 'Please authorize the proper permissions')
        }  
    },
    'SayHello': function () {
        this.emit(':tell', 'Hello World!');
    }
};

function httpsGet(deviceId, consentToken, callback) {

    var options = {
                hostname: 'api.amazonalexa.com',
                port: 443,
                path: `/v1/devices/${deviceId}/settings/address/countryAndPostalCode`,
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${consentToken}`
                },
                accept: 'application/json'
    };

    var req = https.request(options, res => {
        res.setEncoding('utf8');
        var returnData = "";

        res.on('data', chunk => {
            console.log("data is: ", chunk)
            returnData += chunk;
        });

        res.on('end', () => {
            // we have now received the raw return data in the returnData variable.
            // We can see it in the log output via:
            // console.log(JSON.stringify(returnData))
            // we may need to parse through it to extract the needed data
            console.log("return data is: ", returnData)
            var zip = JSON.parse(returnData).postalCode;
            console.log("zip is: ", zip)
            callback(zip);  // this will execute whatever function the caller defined, with one argument

        });

    });
    req.end();

}